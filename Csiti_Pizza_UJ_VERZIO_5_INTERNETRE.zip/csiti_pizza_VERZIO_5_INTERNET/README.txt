CSÍTI PIZZA – KÜLÖN PIZZAOLDALAS VÁLTOZAT

1. Telepíts Node.js 18 vagy újabb verziót.
2. Csomagold ki a ZIP fájlt.
3. Windows alatt indítsd a START_WINDOWS.bat fájlt.
4. Vásárlói oldal: http://localhost:3000
5. Adminoldal: http://localhost:3000/admin.html
6. Admin jelszó: csiti123

MŰKÖDÉS:
- A főoldalon minden pizza külön kártya.
- A pizzára kattintva külön oldal nyílik.
- Ott választható méret, extra, és külön szöveges kérés.
- Kosár után külön befejező/fizetési oldal nyílik.
- Ott adható meg név, cím, telefon, fizetési mód.
- A teljes ár automatikusan számolódik.
- Elküldés után a rendelés megjelenik az adminoldalon.


ÚJ ADMIN FUNKCIÓK:
- Új rendelés: narancssárga
- Készítés alatt: sárga
- Kész: kék
- Átadva: zöld
- Minden rendelés külön törölhető a „Rendelés törlése” gombbal
