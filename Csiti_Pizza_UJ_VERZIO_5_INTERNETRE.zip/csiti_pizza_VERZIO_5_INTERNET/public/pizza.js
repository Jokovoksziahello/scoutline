
let pizza,extras=[],selectedSize='28';
const id=location.pathname.split('/').filter(Boolean).pop();
fetch('/api/menu').then(r=>r.json()).then(d=>{pizza=d.menu.find(x=>x.id===id);extras=d.extras;if(!pizza){document.querySelector('#detail').innerHTML='<div class="empty">Nincs ilyen pizza.</div>';return}document.title=pizza.name+' – CsíTi Pizza';render()});
function calc(){return pizza.prices[selectedSize]+[...document.querySelectorAll('.extra input:checked')].reduce((s,x)=>s+(extras.find(e=>e.id===x.value)?.price||0),0)}
function update(){document.querySelector('#livePrice').textContent=money(calc())}
function render(){document.querySelector('#detail').innerHTML=`<section class="pizza-visual photo"><img class="pizza-detail-img" src="${pizza.image}" alt="${pizza.name}"><div class="pizza-photo-caption"><span class="kicker">CSÍTI PIZZA</span><h1>${pizza.name}</h1><p>${pizza.description}</p></div></section>
<section class="config"><h2>Állítsd össze</h2><div class="block"><h3>1. Méret</h3><div class="sizes">${Object.entries(pizza.prices).map(([s,v])=>`<button class="size ${s==='28'?'active':''}" data-size="${s}">${s} cm<br>${money(v)}</button>`).join('')}</div></div>
<div class="block"><h3>2. Extra feltétek</h3><div class="extras">${extras.map(e=>`<label class="extra"><span><input type="checkbox" value="${e.id}"> ${e.name}</span><b>+${money(e.price)}</b></label>`).join('')}</div></div>
<div class="block"><h3>3. Külön kérés</h3><textarea id="customText" placeholder="Például: hagyma nélkül, jól sült legyen, fél pizzán ne legyen kukorica..."></textarea></div>
<div class="live-price"><span>Aktuális ár</span><span id="livePrice">${money(pizza.prices['28'])}</span></div><button id="addCart" class="btn orange wide">Kosárba</button></section>`;
document.querySelectorAll('.size').forEach(b=>b.onclick=()=>{selectedSize=b.dataset.size;document.querySelectorAll('.size').forEach(x=>x.classList.remove('active'));b.classList.add('active');update()});
document.querySelectorAll('.extra input').forEach(x=>x.onchange=update);
document.querySelector('#addCart').onclick=()=>{const cart=getCart();cart.push({id:Date.now()+Math.random(),pizzaId:pizza.id,name:pizza.name,size:selectedSize,extras:[...document.querySelectorAll('.extra input:checked')].map(x=>x.value),customText:document.querySelector('#customText').value.trim(),qty:1});setCart(cart);toast('A pizza bekerült a kosárba');setTimeout(()=>location.href='/checkout',600)};
}
