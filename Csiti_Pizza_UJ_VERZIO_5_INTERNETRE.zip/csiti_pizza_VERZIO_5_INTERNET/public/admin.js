
const money=n=>new Intl.NumberFormat('hu-HU').format(n)+' Ft';
let token=sessionStorage.getItem('csitiToken')||'',soundOn=false;
const $=s=>document.querySelector(s);

function toast(t){
  const e=$('#toast');
  e.textContent=t;
  e.classList.add('show');
  setTimeout(()=>e.classList.remove('show'),2200);
}
function beep(){
  if(!soundOn)return;
  const c=new AudioContext(),o=c.createOscillator();
  o.connect(c.destination);
  o.frequency.value=880;
  o.start();
  setTimeout(()=>{o.stop();c.close()},550);
}
async function api(url,opt={}){
  opt.headers={...(opt.headers||{}),Authorization:'Bearer '+token};
  const r=await fetch(url,opt);
  const j=await r.json();
  if(!r.ok)throw Error(j.error);
  return j;
}
function statusClass(status){
  if(status==='Készítés alatt')return 'status-making';
  if(status==='Kész')return 'status-ready';
  if(status==='Átadva')return 'status-delivered';
  return 'status-new';
}
async function start(){
  $('#login').hidden=true;
  $('#panel').hidden=false;
  await load();
  const es=new EventSource('/api/stream?token='+encodeURIComponent(token));
  es.addEventListener('new-order',()=>{
    beep();
    toast('Új rendelés érkezett');
    load();
  });
}
async function load(){
  const {orders}=await api('/api/orders');
  const root=$('#orders');
  root.innerHTML=orders.length?'':'<div class="empty">Nincs rendelés.</div>';

  orders.forEach(o=>{
    const cls=statusClass(o.status);
    const e=document.createElement('article');
    e.className=`order ${cls}`;

    e.innerHTML=`
      <div class="order-topline">
        <div>
          <span class="status-badge ${cls}">${o.status}</span>
          <h2>#${o.id} – ${o.customer.name}</h2>
          <p>${new Date(o.createdAt).toLocaleString('hu-HU')}</p>
        </div>
        <div class="order-price">${money(o.total)}</div>
      </div>

      <p>
        <b>Telefon:</b> ${o.customer.phone}<br>
        <b>Átvétel:</b> ${o.customer.delivery}<br>
        <b>Cím:</b> ${o.customer.address||'-'}<br>
        <b>Fizetés:</b> ${o.customer.payment}
      </p>

      <ul>
        ${o.items.map(i=>`
          <li>
            ${i.qty}× <b>${i.name}</b> ${i.size} cm
            ${i.extras.length?' – '+i.extras.map(x=>x.name).join(', '):''}
            ${i.customText?'<br><b>Külön kérés:</b> '+i.customText:''}
          </li>
        `).join('')}
      </ul>

      ${o.customer.note?`<p><b>Rendelési megjegyzés:</b> ${o.customer.note}</p>`:''}

      <div class="actions">
        ${['Készítés alatt','Kész','Átadva'].map(s=>
          `<button class="${o.status===s?'active-status':''}" data-status="${s}">${s}</button>`
        ).join('')}
        <button class="delete-order">Rendelés törlése</button>
      </div>
    `;

    e.querySelectorAll('[data-status]').forEach(b=>{
      b.onclick=async()=>{
        await api('/api/orders/'+o.id,{
          method:'PATCH',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({status:b.dataset.status})
        });
        load();
      };
    });

    e.querySelector('.delete-order').onclick=async()=>{
      if(!confirm(`Biztosan törlöd a #${o.id} rendelést?`))return;
      await api('/api/orders/'+o.id,{method:'DELETE'});
      toast('Rendelés törölve');
      load();
    };

    root.appendChild(e);
  });
}

$('#loginForm').onsubmit=async e=>{
  e.preventDefault();
  const r=await fetch('/api/login',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({password:new FormData(e.target).get('password')})
  });
  const j=await r.json();
  if(!r.ok)return toast(j.error);
  token=j.token;
  sessionStorage.setItem('csitiToken',token);
  start();
};

$('#sound').onclick=()=>{
  soundOn=true;
  beep();
  $('#sound').textContent='Hang bekapcsolva';
};

if(token)start();
