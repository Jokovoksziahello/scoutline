
const money=n=>new Intl.NumberFormat('hu-HU').format(n)+' Ft';
const getCart=()=>JSON.parse(localStorage.getItem('csitiCart')||'[]');
const setCart=c=>{localStorage.setItem('csitiCart',JSON.stringify(c));updateCartBadge()};
function updateCartBadge(){document.querySelectorAll('[data-cart-count]').forEach(e=>e.textContent=getCart().reduce((s,x)=>s+x.qty,0))}
function toast(t){const e=document.querySelector('#toast');if(!e)return;e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),2200)}
updateCartBadge();
