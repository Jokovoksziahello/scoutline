
const form=document.querySelector('#statusForm'),result=document.querySelector('#statusResult');
const labels={
 'Új':'A rendelésed megérkezett.',
 'Készítés alatt':'A pizzádat éppen készítik.',
 'Kész':'A rendelésed elkészült.',
 'Átadva':'A rendelést már átadták.'
};
function cls(s){return s==='Átadva'?'delivered':s==='Kész'?'ready':s==='Készítés alatt'?'making':'new'}
async function lookup(id,phone){
 const r=await fetch('/api/order-status?id='+encodeURIComponent(id)+'&phone='+encodeURIComponent(phone));
 const j=await r.json();
 if(!r.ok){result.innerHTML=`<div class="status-result error">${j.error||'Nem található.'}</div>`;return}
 result.innerHTML=`<section class="status-result ${cls(j.order.status)}">
 <span class="status-pill">${j.order.status}</span>
 <h2>#${j.order.id}</h2><p>${labels[j.order.status]||j.order.status}</p>
 <p><b>Összeg:</b> ${money(j.order.total)}<br><b>Leadva:</b> ${new Date(j.order.createdAt).toLocaleString('hu-HU')}</p>
 <ul>${j.order.items.map(i=>`<li>${i.qty}× ${i.name} – ${i.size} cm</li>`).join('')}</ul></section>`;
}
form.onsubmit=e=>{e.preventDefault();const f=new FormData(form),id=f.get('id'),phone=f.get('phone');localStorage.setItem('csitiLastOrder',JSON.stringify({id,phone}));lookup(id,phone)};
const last=JSON.parse(localStorage.getItem('csitiLastOrder')||'null');
if(last){form.id.value=last.id;form.phone.value=last.phone;lookup(last.id,last.phone)}
