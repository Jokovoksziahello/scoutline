
let menu=[];
fetch('/api/menu').then(r=>r.json()).then(d=>{menu=d.menu;render()});
function render(q=''){
 const g=document.querySelector('#grid');g.innerHTML='';
 menu.filter(p=>(p.name+' '+p.description).toLowerCase().includes(q.toLowerCase())).forEach(p=>{
  const a=document.createElement('a');a.className='pizza-card';a.href='/pizza/'+p.id;a.style.textDecoration='none';
  a.innerHTML=`<img class="pizza-card-img" src="${p.image}" alt="${p.name}">
  <h3>${p.name}</h3><p>${p.description}</p>
  <div class="price-row"><span>20 cm: ${money(p.prices['20'])}</span><span>28 cm: ${money(p.prices['28'])}</span></div>
  <span class="btn orange">Megnézem és összeállítom</span>`;
  g.appendChild(a)
 })
}
document.querySelector('#search').oninput=e=>render(e.target.value);
