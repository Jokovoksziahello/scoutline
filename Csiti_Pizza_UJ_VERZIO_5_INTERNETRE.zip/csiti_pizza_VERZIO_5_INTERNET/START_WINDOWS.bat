@echo off
title Csiti Pizza UJ VERZIO 4
set PORT=3020
start "" http://localhost:3020
start "" http://localhost:3020/admin.html
node server.js
pause
