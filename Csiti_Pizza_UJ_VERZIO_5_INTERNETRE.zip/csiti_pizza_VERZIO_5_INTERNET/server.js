
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),{URL}=require('url');
const ROOT=__dirname,PUBLIC=path.join(ROOT,'public');
const SOURCE_DATA=path.join(ROOT,'data');
const DATA=process.env.DATA_DIR||SOURCE_DATA;
if(!fs.existsSync(DATA))fs.mkdirSync(DATA,{recursive:true});
for(const file of ['menu.json','orders.json']){
  const target=path.join(DATA,file),source=path.join(SOURCE_DATA,file);
  if(!fs.existsSync(target)&&fs.existsSync(source))fs.copyFileSync(source,target);
}
const PORT=process.env.PORT||3020,PASS=process.env.ADMIN_PASSWORD||'csiti123',clients=new Set();
const read=(f,d)=>{try{return JSON.parse(fs.readFileSync(path.join(DATA,f),'utf8'))}catch{return d}};
const write=(f,v)=>fs.writeFileSync(path.join(DATA,f),JSON.stringify(v,null,2),'utf8');
const send=(res,c,v)=>{res.writeHead(c,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(v))};
const body=req=>new Promise((ok,no)=>{let b='';req.on('data',c=>{b+=c;if(b.length>1e6)no(Error('Túl nagy kérés'))});req.on('end',()=>{try{ok(b?JSON.parse(b):{})}catch{no(Error('Hibás adat'))}})});
const auth=req=>(req.headers.authorization||'')===`Bearer ${PASS}`;
const emit=(event,payload)=>clients.forEach(r=>r.write(`event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`));
const mime=f=>({'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.jpg':'image/jpeg','.png':'image/png'}[path.extname(f).toLowerCase()]||'application/octet-stream');

http.createServer(async(req,res)=>{
 try{
  const u=new URL(req.url,`http://${req.headers.host}`),p=u.pathname;
  if(p==='/api/health')return send(res,200,{ok:true});
  if(p==='/api/menu'&&req.method==='GET')return send(res,200,read('menu.json',{menu:[],extras:[]}));
  if(p==='/api/order'&&req.method==='POST'){
    const b=await body(req),cat=read('menu.json',{menu:[],extras:[]});
    if(!b.customer?.name||!b.customer?.phone||!b.customer?.payment||!Array.isArray(b.items)||!b.items.length)
      return send(res,400,{error:'Tölts ki minden kötelező adatot.'});
    if(b.customer.delivery==='Kiszállítás'&&!b.customer.address)
      return send(res,400,{error:'Kiszállításhoz add meg a címet.'});
    let total=0,clean=[];
    for(const x of b.items){
      const pizza=cat.menu.find(z=>z.id===x.pizzaId);
      if(!pizza||!pizza.prices[x.size])return send(res,400,{error:'Érvénytelen pizza vagy méret.'});
      const chosen=(x.extras||[]).map(id=>cat.extras.find(e=>e.id===id)).filter(Boolean);
      const unit=pizza.prices[x.size]+chosen.reduce((s,e)=>s+e.price,0);
      const qty=Math.max(1,Math.min(20,Number(x.qty)||1));
      total+=unit*qty;
      clean.push({name:pizza.name,size:x.size,extras:chosen,customText:String(x.customText||'').slice(0,300),qty,unitPrice:unit});
    }
    const orders=read('orders.json',[]);
    const order={id:crypto.randomInt(100000,999999),createdAt:new Date().toISOString(),status:'Új',
      customer:{name:String(b.customer.name).slice(0,80),phone:String(b.customer.phone).slice(0,40),
      delivery:String(b.customer.delivery),address:String(b.customer.address||'').slice(0,200),
      payment:String(b.customer.payment),note:String(b.customer.note||'').slice(0,400)},items:clean,total};
    orders.unshift(order);write('orders.json',orders);emit('new-order',order);
    return send(res,201,{ok:true,id:order.id,total});
  }
  if(p==='/api/order-status'&&req.method==='GET'){
    const id=u.searchParams.get('id'),phone=(u.searchParams.get('phone')||'').replace(/\s+/g,'');
    const order=read('orders.json',[]).find(o=>String(o.id)===String(id)&&String(o.customer.phone||'').replace(/\s+/g,'')===phone);
    if(!order)return send(res,404,{error:'Nem található ilyen rendelés ezzel a telefonszámmal.'});
    return send(res,200,{order:{id:order.id,createdAt:order.createdAt,status:order.status,total:order.total,items:order.items}});
  }
  if(p==='/api/login'&&req.method==='POST'){const b=await body(req);return send(res,b.password===PASS?200:401,b.password===PASS?{token:PASS}:{error:'Hibás jelszó'})}
  if(p==='/api/orders'&&req.method==='GET'){if(!auth(req))return send(res,401,{error:'Nincs jogosultság'});return send(res,200,{orders:read('orders.json',[])})}
  if(p==='/api/stream'&&req.method==='GET'){if(u.searchParams.get('token')!==PASS){res.writeHead(401);return res.end()}res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive'});res.write('event: ready\ndata: {}\n\n');clients.add(res);req.on('close',()=>clients.delete(res));return}
  const m=p.match(/^\/api\/orders\/(\d+)$/);
  if(m&&req.method==='PATCH'){if(!auth(req))return send(res,401,{error:'Nincs jogosultság'});const b=await body(req),orders=read('orders.json',[]),o=orders.find(x=>String(x.id)===m[1]);if(!o)return send(res,404,{error:'Nincs ilyen rendelés'});o.status=b.status||o.status;write('orders.json',orders);return send(res,200,{ok:true})}
  if(m&&req.method==='DELETE'){if(!auth(req))return send(res,401,{error:'Nincs jogosultság'});const orders=read('orders.json',[]),next=orders.filter(x=>String(x.id)!==m[1]);if(next.length===orders.length)return send(res,404,{error:'Nincs ilyen rendelés'});write('orders.json',next);return send(res,200,{ok:true})}

  let route=p;
  if(p.startsWith('/pizza/')) route='/pizza.html';
  if(p==='/checkout') route='/checkout.html';
  if(p==='/menu') route='/menu.html';
  if(p==='/rendelesek') route='/orders.html';
  let file=route==='/'?path.join(PUBLIC,'index.html'):path.normalize(path.join(PUBLIC,route));
  if(!file.startsWith(PUBLIC)||!fs.existsSync(file)){res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});return res.end('Az oldal nem található.')}
  res.writeHead(200,{
    'Content-Type':mime(file),
    'X-Content-Type-Options':'nosniff',
    'X-Frame-Options':'SAMEORIGIN',
    'Referrer-Policy':'strict-origin-when-cross-origin'
  });fs.createReadStream(file).pipe(res);
 }catch(e){console.error(e);send(res,500,{error:'Szerverhiba'})}
}).listen(PORT,()=>console.log(`CsíTi Pizza: http://localhost:${PORT}`));
