CSÍTI PIZZA – ÚJ VERZIÓ 4

1. Zárd be a régi fekete parancssori ablakokat.
2. Csomagold ki ezt a ZIP-et egy teljesen új mappába.
3. Kattints a START_WINDOWS.bat fájlra.

Vásárlói oldal: http://localhost:3020
Adminoldal: http://localhost:3020/admin.html
Admin jelszó: csiti123

Újdonságok:
- Minden pizzához külön, feltétek alapján elkészített valósághű illusztráció.
- Felső menüsor: Pizzák / Menü / Rendelések.
- A Menü oldalon az eredeti elküldött étlap látható.
- A Rendelések oldalon rendelési szám és telefonszám alapján látható az állapot.
- Rendelés után automatikusan elmenti a követéshez szükséges adatokat.
- Adminban színes állapotok és rendeléstörlés.
